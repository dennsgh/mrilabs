# Will be populated during runtime on memory
function_map:dict = {}